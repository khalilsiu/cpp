#include <iostream>
#include <memory>
#include <cstddef>
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
using namespace std;

struct Node
{
    int data;
    Node *next;
};

class LinkedList
{
private:
    Node *head;
    Node *tail;

public:
    LinkedList()
    {
        head = nullptr;
        tail = nullptr;
    }

    int Front()
    {
        return head->data;
    }

    int Back()
    {
        return tail->data;
    }

    bool Empty()
    {
        return !head;
    }

    int Size()
    {
        Node *temp = new Node;
        temp = head;
        int length = 0;
        while (temp != nullptr)
        {
            length += 1;
            temp = temp->next;
        }
        return length;
    }

    void Clear()
    {
        head = nullptr;
        tail = nullptr;
        return;
    }

    // insert is pass by value, tried just passing by value of newNode, but the local variable goes out of scope, could not be accessed outside
    void Insert(int pos, Node newNode, int value_num = 0)
    {
        int length = this->Size();
        if (pos > length)
        {
            cout << "Position is out of range" << endl;
            return;
        }
        if (value_num == 0)
        {
            Node *temp = new Node;
            temp->data = newNode.data;
            if (pos == 0)
            {
                temp->next = head;
                head = temp;
                temp = nullptr;
                delete temp;
                return;
            }
            Node *cur = new Node;
            Node *pre = new Node;
            cur = head;
            for (int i = 0; i < pos; i++)
            {
                pre = cur;
                cur = cur->next;
            }
            temp->next = cur;
            pre->next = temp;
            if (cur == nullptr)
            {
                tail = temp;
            }
            temp = nullptr;
            cur = nullptr;
            pre = nullptr;
            delete cur;
            delete pre;
            delete temp;
            return;
        }
        else
        {
            for (int i = 0; i < value_num; i++)
            {
                if (pos == 0)
                {
                    Node *temp = new Node;
                    temp->data = newNode.data;
                    temp->next = head;
                    head = temp;
                    temp = nullptr;
                    delete temp;
                }
                else
                {
                    Node *cur = new Node;
                    Node *pre = new Node;
                    Node *temp = new Node;
                    temp->data = newNode.data;
                    cur = head;
                    for (int j = 0; j < pos + i; j++)
                    {
                        pre = cur;
                        cur = cur->next;
                    }
                    temp->next = cur;
                    pre->next = temp;
                    if (length == pos && i == value_num - 1)
                    {
                        tail = temp;
                    }
                    temp = nullptr;
                    cur = nullptr;
                    pre = nullptr;
                    cout << tail->data << endl;
                    cout << tail->next << endl;
                    delete temp;
                    delete cur;
                    delete pre;
                }
            }
            return;
        }
    }

    void Emplace(int pos, int value)
    {
        Node *temp = new Node;
        temp->data = value;
        int length = this->Size();
        if (pos > length)
        {
            cout << "Position is out of range" << endl;
            return;
        }
        if (pos == 0)
        {
            temp->next = head;
            head = temp;
            temp = nullptr;
            delete temp;
            return;
        }
        Node *cur = new Node;
        Node *pre = new Node;
        cur = head;
        for (int i = 0; i < pos; i++)
        {
            pre = cur;
            cur = cur->next;
        }
        temp->next = cur;
        pre->next = temp;
        if (length == pos)
        {
            tail = temp;
        }
        temp = nullptr;
        cur = nullptr;
        pre = nullptr;
        delete temp;
        delete cur;
        delete pre;
        return;
    }

    void Erase(int start, int end = 0)
    {
        int length = this->Size();
        if (start >= length || end > length)
        {
            cout << "Position is out of range" << endl;
            return;
        }
        if (end != 0 && start >= end)
        {
            cout << "End index must be larger than start" << endl;
            return;
        }
        if (end == 0)
        {
            if (start == 0)
            {
                head = head->next;
                return;
            }
            Node *cur = new Node;
            Node *pre = new Node;
            cur = head;
            for (int i = 0; i < start; i++)
            {
                pre = cur;
                cur = cur->next;
            }
            pre->next = cur->next;
            if (start == length - 1)
            {
                tail = pre;
            }
            pre = nullptr;
            cur = nullptr;
            delete pre;
            delete cur;
            return;
        }
        else
        {
            int times = end - start;
            for (int i = 0; i < times; i++)
            {
                if (start == 0)
                {
                    head = head->next;
                }
                else
                {
                    Node *cur = new Node;
                    Node *pre = new Node;
                    cur = head;
                    for (int j = 0; j < start; j++)
                    {
                        pre = cur;
                        cur = cur->next;
                    }
                    pre->next = cur->next;
                    pre = nullptr;
                    cur = nullptr;
                    delete pre;
                    delete cur;
                }
            }
            cout << "size " << this->Size() << endl;
            return;
        }
    }

    // using tail
    void PushBack(int value)
    {
        Node *temp = new Node;
        temp->data = value;
        temp->next = nullptr;
        if (head == nullptr)
        {
            head = temp;
            tail = temp;
            temp = nullptr;
            delete temp;
            return;
        }
        else
        {
            tail->next = temp;
            tail = temp;
            temp = nullptr;
            delete temp;
            return;
        }
    }

    // using tail
    void PopBack()
    {
        if (head == nullptr)
        {
            cout << "List is empty" << endl;
            return;
        }
        if (head->next == nullptr)
        {
            head = nullptr;
            tail = nullptr;
            return;
        }
        Node *pre = new Node;
        Node *cur = new Node;
        cur = head;
        while (cur->next != nullptr)
        {
            pre = cur;
            cur = cur->next;
        }
        tail = pre;
        tail->next = nullptr;
        pre = nullptr;
        cur = nullptr;
        delete pre;
        delete cur;
        return;
    }

    void PushFront(int value)
    {
        Node *temp = new Node;
        temp->data = value;
        temp->next = head;
        head = temp;
        temp = nullptr;
        delete temp;
        return;
    }

    void PopFront()
    {
        Node *temp = new Node;
        temp = head;
        head = head->next;
        temp = nullptr;
        delete temp;
        return;
    }

    void Resize(int size)
    {
        int length = this->Size();
        if(size == 0)
        {
            head = nullptr;
            tail = nullptr;
            return;
        }
        if (length > size)
        {
            Node *cur = new Node;
            cur = head;
            for (int i = 0; i < size - 1; i++)
            {
                cur = cur->next;
            }
            cur->next = nullptr;
            tail = cur;
            cur = nullptr;
            delete cur;
            return;
        }
        else if (length < size)
        {
            int times = size - length;
            for (int i = 0; i < times; i++)
            {
                Node *temp = new Node;
                temp->data = 0;
                temp->next = nullptr;
                tail->next = temp;
                tail = temp;
                temp = nullptr;
                delete temp;
            }
            return;
        }
    }

    void Swap(LinkedList *another_list)
    {
        Node *temp = new Node;
        temp = head;
        head = another_list->head;
        another_list->head = temp;
        temp = tail;
        tail = another_list-> tail;
        another_list->tail = temp;
        temp = nullptr;
        delete temp;
        return;
    }

    void PrintList()
    {
        Node *temp = new Node;
        temp = head;
        cout << "List elements: \t";
        while (temp != nullptr)
        {
            cout << temp->data << "\t";
            temp = temp->next;
        }
        cout << endl;
        temp = nullptr;
        delete temp;
        return;
    }

    int GetValueAt(int pos)
    {
        Node *cur = new Node;
        cur = head;
        for (int i = 0; i < pos; i++)
        {
            cur = cur->next;
            if (cur == nullptr)
            {
                delete cur;
                return 0;
            }
        }
        int data = cur->data;
        cur = nullptr;
        delete cur;
        return data;
    }

    std::size_t GetSize() const noexcept
    {
        Node *temp = new Node;
        temp = head;
        size_t listSize = 0;
        while (temp != nullptr)
        {
            listSize += sizeof(temp);
            temp = temp->next;
        }
        temp = nullptr;
        delete temp;
        return listSize;
    }
};

TEST_CASE("Linked list elements could be added and removed", "[LinkedList]")
{
    LinkedList new_list;
    new_list.PushBack(2);
    new_list.PushBack(3);
    new_list.PushBack(4);
    new_list.PushBack(5);

    SECTION("front returns the first element in the list")
    {
        REQUIRE(new_list.Front() == 2);
    }
    SECTION("back returns the last element in the list")
    {
        REQUIRE(new_list.Back() == 5);
    }
    SECTION("empty returns false if list is not empty")
    {
        REQUIRE(!new_list.Empty());
    }
    SECTION("size returns length of list")
    {
        REQUIRE(new_list.Size() == 4);
    }
    SECTION("clear removes all elements in the list")
    {
        new_list.Clear();
        REQUIRE(new_list.Empty());
    }
    SECTION("getSize returns the number of bytes of the list")
    {
        REQUIRE(new_list.GetSize() == 32);
    }
    SECTION("push_back adds an element to the end")
    {
        new_list.PushBack(6);
        REQUIRE(new_list.GetValueAt(4) == 6);
        new_list.PrintList();
    }
    SECTION("push_front adds an element to the front")
    {
        new_list.PushFront(1);
        REQUIRE(new_list.GetValueAt(0) == 1);
        new_list.PrintList();
    }
    SECTION("pop_back removes an element from the end")
    {
        new_list.PopBack();
        REQUIRE(new_list.GetValueAt(2) == 4);
        new_list.PrintList();
    }
    SECTION("pop_front removes an element from the front")
    {
        new_list.PopFront();
        REQUIRE(new_list.GetValueAt(0) == 3);
        new_list.PrintList();
    }
    SECTION("insert inserts initialized element at position for a number of times")
    {
        Node newNode;
        newNode.data = 6;
        newNode.next = nullptr;
        new_list.Insert(0,newNode,3);
        bool testPassed = (new_list.GetValueAt(0) == 6 && new_list.GetValueAt(1) == 6 && new_list.GetValueAt(2) == 6);
        REQUIRE(testPassed);
        new_list.PrintList();
    }
    SECTION("emplace insert an element at position")
    {
        new_list.Emplace(3,8);
        REQUIRE(new_list.GetValueAt(3) == 8);
        new_list.PrintList();
    }
    SECTION("erase removes an element at a position if end is not specified")
    {
        new_list.Erase(2);
        REQUIRE(new_list.GetValueAt(2) == 5);
        new_list.PrintList();
    }
    SECTION("erase removes elements from start to end exclusive")
    {
        new_list.Erase(0,3);
        REQUIRE(new_list.GetValueAt(0) == 5);
        new_list.PrintList();
    }
    SECTION("resize resizes list removing elements if size is shorter")
    {
        new_list.Resize(2);
        REQUIRE(new_list.GetValueAt(1) == 3);
        new_list.PrintList();
    }
    SECTION("resize expands list by pushing 0 to the end if size is larger")
    {
        new_list.Resize(7);
        REQUIRE(new_list.GetValueAt(6) == 0);
        new_list.PrintList();
    }
    SECTION("swap swaps contents of two lists")
    {
        LinkedList another_list;
        another_list.PushBack(5);
        another_list.PushBack(4);
        another_list.PushBack(3);
        another_list.PushBack(2);
        new_list.Swap(&another_list);
        bool testPassed = (new_list.GetValueAt(0) == 5 && another_list.GetValueAt(0) == 2);
        REQUIRE(testPassed);
        cout << "Original List: \t";
        new_list.PrintList();
        cout << endl;
        cout << "Another List: \t";
        another_list.PrintList();
        cout << endl;

    }
}

// Create a Node: pointer of Node type, insert value in its data field, next is NULL

// If linkedlist is still empty: check, if head = NULL, empty

// If just one Node: it's called both head and tail

// If list is created already: we would insert at the tail, add newly created Node to a tail

// int main()
// {
//     LinkedList new_list;
//     new_list.push_back(2);
//     new_list.push_back(3);
//     new_list.push_back(4);
//     new_list.push_back(5);

//     LinkedList another_list;
//     another_list.push_back(5);
//     another_list.push_back(4);
//     another_list.push_back(3);
//     another_list.push_back(2);

//     new_list.swap(&another_list);


//     new_list.printList();
//     another_list.printList();
    
// }
